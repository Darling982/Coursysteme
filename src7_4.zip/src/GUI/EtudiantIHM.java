package GUI;

import dao.EtudiantDAO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;
import stockage.StudentStatut;

public class EtudiantIHM {

	 private JFrame jframe;
	 
	   public static void main(String[] args) {
	        SwingUtilities.invokeLater(() -> {
	            EtudiantIHM menu = new EtudiantIHM();
	            menu.getJframe().setVisible(true);
	        });
	    }  
	  
	 public EtudiantIHM() {
	      
	        initialize();  // Initialisation de l'interface
	    }

		  
		    private void initialize() {
		        setJframe(new JFrame("Menu Etudiant"));
		        getJframe().getContentPane().setFont(new Font("Times New Roman", Font.BOLD, 14));
		        getJframe().getContentPane().setBackground(new Color(175, 96, 255));
		        getJframe().getContentPane().setForeground(new Color(0, 0, 0));
		        getJframe().setBounds(100, 100, 600, 650);
		        getJframe().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        getJframe().getContentPane().setLayout(null);
		        
		        JButton btnNewButton = new JButton("FAIRE MES CHOIX");
		        btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		        btnNewButton.setBounds(95, 211, 409, 75);
		        getJframe().getContentPane().add(btnNewButton);
		        
		       
		       
		        
		        JButton btnNewButton_1 = new JButton("VOIR MES INFOS");
		        btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		        btnNewButton_1.addActionListener(new ActionListener() {
		        	
		        	public void actionPerformed(ActionEvent e) {
		        	}
		        });
		        btnNewButton_1.setBounds(95, 413, 409, 75);
		        getJframe().getContentPane().add(btnNewButton_1);
		        
		        JLabel lblNewLabel = new JLabel("MENU");
		        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 34));
		        lblNewLabel.setBounds(216, 81, 139, 51);
		        getJframe().getContentPane().add(lblNewLabel);
		        
		        JButton btnNewButton_2 = new JButton("Retour");
		        btnNewButton_2.addActionListener(new ActionListener() {
		        	
		       
		        	public void actionPerformed(ActionEvent e) {
		        		 getJframe().dispose();
		        		SwingUtilities.invokeLater(() -> {
		    	            loginGUI login = new loginGUI();
		    	            login.getFrame().setVisible(true);
		    	        });
		        	}
		        });
		        btnNewButton_2.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		        btnNewButton_2.setForeground(new Color(128, 0, 128));
		        btnNewButton_2.setBounds(10, 23, 85, 21);
		        getJframe().getContentPane().add(btnNewButton_2);
		        
		        btnNewButton.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent e) {
	
		            	//ouvre la fenêtre de choix selon le statut de l'étudiant 
		 		       
		 		       
				        String statut;
				        String identifiant;
				        identifiant = StudentStatut.getIdStudent();
				        statut = EtudiantDAO.getStudentStatus(identifiant);
				        
				        if ("FISE".equals(statut))
				        {
				       
				        	choix_FISE fise = new choix_FISE();
				        }
				        else if("FISA".equals(statut)) {
				        	
				        	choix_FISA fisa = new choix_FISA();
				        }
				        
				        else {
				            JOptionPane.showMessageDialog(getJframe(), "Statut inconnu : " + statut, "Erreur", JOptionPane.ERROR_MESSAGE);
				        }
		            }
		        });
		        
		        btnNewButton_1.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent e) {
		                new VoirInfo();
		                getJframe().setVisible(false); // cache la fenêtre mais elle reste en mémoire
		            }
		        });		        
		        
                getJframe().setVisible(true);
		        
		    }

			public JFrame getJframe() {
				return jframe;
			}

			public void setJframe(JFrame jframe) {
				this.jframe = jframe;
			}        
	    }


package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProcedureDAO {

    public static boolean isFiseOuvert() {
        try (Connection conn = ConnectionDAO.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT FISE_OUVERT FROM PROCEDURE_STATUT WHERE ID = 1");
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("FISE_OUVERT") == 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean isFisaOuvert() {
        try (Connection conn = ConnectionDAO.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT FISA_OUVERT FROM PROCEDURE_STATUT WHERE ID = 1");
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("FISA_OUVERT") == 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void setFiseOuvert(boolean ouvert) {
        try (Connection conn = ConnectionDAO.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE PROCEDURE_STATUT SET FISE_OUVERT = ? WHERE ID = 1")) {
            stmt.setInt(1, ouvert ? 1 : 0);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setFisaOuvert(boolean ouvert) {
        try (Connection conn = ConnectionDAO.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE PROCEDURE_STATUT SET FISA_OUVERT = ? WHERE ID = 1")) {
            stmt.setInt(1, ouvert ? 1 : 0);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
